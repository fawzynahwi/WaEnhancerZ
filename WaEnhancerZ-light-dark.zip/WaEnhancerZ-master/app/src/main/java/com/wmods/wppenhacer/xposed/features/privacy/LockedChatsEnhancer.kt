package com.wmods.wppenhacer.xposed.features.privacy

import android.content.SharedPreferences
import com.highcapable.kavaref.KavaRef.Companion.resolve
import com.highcapable.yukihookapi.extension.kavaref.hook
import com.highcapable.yukihookapi.extension.kavaref.hookAll
import com.wmods.wppenhacer.xposed.core.Feature
import com.wmods.wppenhacer.xposed.core.components.FMessageWpp.UserJid
import com.wmods.wppenhacer.xposed.core.components.WaContactWpp
import com.wmods.wppenhacer.xposed.core.devkit.Unobfuscator.loadChatCacheClass
import com.wmods.wppenhacer.xposed.core.devkit.Unobfuscator.loadLoadedContactsMethod
import com.wmods.wppenhacer.xposed.core.devkit.Unobfuscator.loadLockedChatsMethod
import com.wmods.wppenhacer.xposed.core.devkit.Unobfuscator.loadNotificationMethod
import com.wmods.wppenhacer.xposed.utils.ReflectionUtils

class LockedChatsEnhancer(classLoader: ClassLoader, preferences: SharedPreferences) :
    Feature(classLoader, preferences) {
    private var chatCache: Any? = null

    override fun doHook() {
        if (!xprefs.getBoolean("lockedchats_enhancer", false)) return

        val jidNotifications = loadNotificationMethod(classLoader)
        val lockedChatsMethod = loadLockedChatsMethod(classLoader)
        val suppressLockedChats = ThreadLocal.withInitial { false }

        jidNotifications.hook {
            before {
                suppressLockedChats.set(true)
            }
            after {
                suppressLockedChats.remove()
            }
        }

        lockedChatsMethod.hook {
            before {
                if (suppressLockedChats.get() == true) {
                    result = (ArrayList<Any?>())
                }
            }
        }

        val chatCacheClass = loadChatCacheClass(classLoader)
        val lockedChatsFields = ReflectionUtils.findAllFieldsUsingFilter(chatCacheClass) { f ->
            f.type == HashSet::class.java
        }
        val lockedChatsField = lockedChatsFields.getOrNull(1) ?: lockedChatsFields.firstOrNull() ?: return

        chatCacheClass.resolve().constructor { }.hookAll {
            before {
                chatCache = instance
            }
        }

        val loadedContacts = loadLoadedContactsMethod(classLoader)

        loadedContacts!!.hook {
            before {
                val listField = args[0]?.javaClass?.declaredFields?.firstOrNull {
                    List::class.java.isAssignableFrom(it.type)
                } ?: return@before
                listField.isAccessible = true
                val list = listField.get(args[0]) as? List<*> ?: return@before
                val cache = chatCache ?: return@before
                val lockedChats = lockedChatsField.get(cache) as? HashSet<*> ?: return@before
                if (lockedChats.isEmpty()) return@before
                val lockedIds = HashSet<String>()
                for (jid in lockedChats) {
                    if (jid == null) continue
                    val userJid = UserJid(jid)
                    userJid.phoneRawString?.let { lockedIds.add(it) }
                    userJid.userRawString?.let { lockedIds.add(it) }
                    userJid.phoneNumber?.let { lockedIds.add(it) }
                }
                val filteredlist = list.filter { item: Any? ->
                    if (!WaContactWpp.TYPE.isInstance(item)) return@filter true
                    val userJid = WaContactWpp(item).userJid
                    listOf(userJid.phoneRawString, userJid.userRawString, userJid.phoneNumber)
                        .none { it != null && it in lockedIds }
                }
                listField.set(args[0], filteredlist)
            }
        }
    }

    public override fun getPluginName(): String {
        return "Locked Chats Enhancer"
    }
}
