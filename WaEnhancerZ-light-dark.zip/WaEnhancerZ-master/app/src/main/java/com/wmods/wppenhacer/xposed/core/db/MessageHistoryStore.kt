package com.wmods.wppenhacer.xposed.core.db

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import androidx.room.Room
import androidx.room.RoomDatabase
import com.wmods.wppenhacer.xposed.core.components.FMessageWpp
import com.wmods.wppenhacer.xposed.core.db.entity.DeviceEntity
import com.wmods.wppenhacer.xposed.core.db.entity.HideSeenEntity
import com.wmods.wppenhacer.xposed.core.db.entity.MessageEntity
import com.wmods.wppenhacer.xposed.utils.Utils
import com.wmods.wppenhacer.xposed.utils.YukiLog
import java.util.concurrent.ConcurrentHashMap

class MessageHistoryStore private constructor(context: Context) {

    enum class ReceiptType {
        READ,
        PLAYED
    }

    interface HideSeenChangeListener {
        fun onHideSeenChanged(jid: String, messageId: String, type: ReceiptType, viewed: Boolean)
    }

    data class MessageItem(
        @JvmField val id: Long,
        @JvmField val message: String,
        @JvmField val timestamp: Long
    )

    class MessageSeenItem(
        @JvmField val jid: String?,
        @JvmField val userjid: String?,
        @JvmField val message: String,
        @JvmField val viewed: Boolean
    ) {
        private var fMessageWpp: FMessageWpp? = null

        val fMessage: FMessageWpp?
            get() {
                if (fMessageWpp == null) {
                    try {
                        val userJid = FMessageWpp.UserJid(userjid ?: jid)
                        if (userJid.isNull) return null
                        fMessageWpp = FMessageWpp.Key(message, userJid, false).fMessage
                    } catch (_: Exception) {
                    }
                }
                return fMessageWpp
            }
    }

    private val messagesCache = LruCache<Long, ArrayList<MessageItem>>(MESSAGE_CACHE_SIZE)
    private val seenMessageCache = LruCache<String, MessageSeenItem>(SEEN_MESSAGE_CACHE_SIZE)
    private val seenMessagesListCache =
        LruCache<String, List<MessageSeenItem>>(SEEN_MESSAGES_LIST_CACHE_SIZE)
    private val deviceCache = LruCache<String, Int>(DEVICE_CACHE_SIZE)
    private val cacheLock = Any()
    private val loadingCacheKeys = ConcurrentHashMap.newKeySet<String>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val db: MessageHistoryDatabase = Room.databaseBuilder(
        context.applicationContext,
        MessageHistoryDatabase::class.java,
        "MessageHistory.db"
    )
        .addMigrations(
            MIGRATION_5_6,
            MessageHistoryDatabase.MIGRATION_6_7,
            MessageHistoryDatabase.MIGRATION_7_8
        )
        .setQueryExecutor(Utils.databaseExecutor)
        .setTransactionExecutor(Utils.databaseExecutor)
        .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
        .fallbackToDestructiveMigration(true)
        .build()

    private val messageDao = db.messageDao()
    private val hideSeenDao = db.hideSeenDao()
    private val deviceDao = db.deviceDao()

    companion object {
        private const val MESSAGE_CACHE_SIZE = 100
        private const val SEEN_MESSAGE_CACHE_SIZE = 200
        private const val SEEN_MESSAGES_LIST_CACHE_SIZE = 50
        private const val DEVICE_CACHE_SIZE = 300
        private const val BATCH_CHUNK_SIZE = 500

        private val MIGRATION_5_6 = object : androidx.room.migration.Migration(5, 6) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS idx_message_history_row_id " +
                            "ON MessageHistory (row_id)"
                )
            }
        }

        private val EMPTY_SEEN_ITEM = MessageSeenItem("", "", "", false)
        private const val EMPTY_DEVICE_TYPE = -1
        private val EMPTY_MESSAGE_LIST = ArrayList<MessageItem>()

        @Volatile
        private var hideSeenChangeListener: HideSeenChangeListener? = null

        @Volatile
        private var mInstance: MessageHistoryStore? = null

        @JvmStatic
        fun getInstance(): MessageHistoryStore {
            return mInstance ?: synchronized(this) {
                mInstance ?: MessageHistoryStore(Utils.application).also { mInstance = it }
            }
        }

        @JvmStatic
        fun setHideSeenChangeListener(listener: HideSeenChangeListener?) {
            hideSeenChangeListener = listener
        }


    }

    fun insertMessage(id: Long, message: String, timestamp: Long) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            insertMessageAsync(id, message, timestamp)
            return
        }
        try {
            messageDao.insert(
                MessageEntity(
                    rowId = id,
                    textData = message,
                    editTimestamp = timestamp
                )
            )
            messagesCache.remove(id)
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
    }

    fun insertMessageAsync(id: Long, message: String, timestamp: Long) {
        Utils.databaseExecutor.execute {
            insertMessage(id, message, timestamp)
        }
    }

    fun recordEditMessageAsync(id: Long, message: String, timestamp: Long) {
        Utils.databaseExecutor.execute {
            try {
                val originalMessage = MessageStore.getInstance().getCurrentMessageByID(id)
                if (getMessages(id) == null) {
                    insertMessage(id, originalMessage, 0)
                }
                insertMessage(id, message, timestamp)
            } catch (t: Throwable) {
                YukiLog.log(t)
            }
        }
    }

    fun getMessages(v: Long): ArrayList<MessageItem>? {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            scheduleCacheLoad("messages:$v") { getMessages(v) }
            return null
        }
        try {
            val cachedMessages = messagesCache.get(v)
            if (cachedMessages != null) {
                return if (cachedMessages === EMPTY_MESSAGE_LIST) null else cachedMessages
            }

            val history = messageDao.getMessagesByRowId(v)
            if (history.isNotEmpty()) {
                val messages = ArrayList<MessageItem>()
                for (entity in history) {
                    messages.add(
                        MessageItem(
                            entity.rowId,
                            entity.textData,
                            entity.editTimestamp ?: 0L
                        )
                    )
                }
                messagesCache.put(v, messages)
                return messages
            } else {
                messagesCache.put(v, EMPTY_MESSAGE_LIST)
            }
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
        return null
    }

    fun getMessagesAsync(v: Long, callback: (ArrayList<MessageItem>) -> Unit) {
        Utils.databaseExecutor.execute {
            val messages = getMessages(v) ?: ArrayList()
            android.os.Handler(Looper.getMainLooper()).post {
                callback(messages)
            }
        }
    }

    fun insertHideSeenMessage(
        jid: String?,
        userJid: String?,
        messageId: String?,
        type: ReceiptType?,
        viewed: Boolean
    ) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            insertHideSeenMessageAsync(jid, userJid, messageId, type, viewed)
            return
        }
        try {
            if (messageId == null || type == null) return
            val jids = buildJidList(jid, userJid)
            if (jids.isEmpty()) return
            val primaryJid = jid ?: userJid!!

            val isViewedInt = if (viewed) 1 else 0

            db.runInTransaction {
                if (type == ReceiptType.PLAYED) {
                    hideSeenDao.insertOrIgnore(
                        HideSeenEntity(
                            jid = primaryJid,
                            userjid = userJid,
                            messageId = messageId,
                            played = isViewedInt
                        )
                    )
                    if (userJid != null) {
                        hideSeenDao.updateUserJidIfNeeded(primaryJid, userJid, messageId)
                    }
                    hideSeenDao.updatePlayed(jids, messageId, isViewedInt)
                } else {
                    hideSeenDao.insertOrIgnore(
                        HideSeenEntity(
                            jid = primaryJid,
                            userjid = userJid,
                            messageId = messageId,
                            read = isViewedInt
                        )
                    )
                    if (userJid != null) {
                        hideSeenDao.updateUserJidIfNeeded(primaryJid, userJid, messageId)
                    }
                    hideSeenDao.updateRead(jids, messageId, isViewedInt)
                }
            }

            val cacheKey = createSeenMessageCacheKey(primaryJid, messageId, type)
            seenMessageCache.remove(cacheKey)
            invalidateSeenMessagesListCache(primaryJid, type)
            hideSeenChangeListener?.onHideSeenChanged(primaryJid, messageId, type, viewed)
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
    }

    fun insertHideSeenMessageAsync(
        jid: String?,
        userJid: String?,
        messageId: String?,
        type: ReceiptType?,
        viewed: Boolean
    ) {
        Utils.databaseExecutor.execute {
            insertHideSeenMessage(jid, userJid, messageId, type, viewed)
        }
    }

    fun insertHideSeenMessagesAsync(
        jid: String?,
        userJid: String?,
        messageIds: Iterable<String?>,
        type: ReceiptType?,
        viewed: Boolean
    ) {
        Utils.databaseExecutor.execute {
            for (messageId in messageIds) {
                insertHideSeenMessage(jid, userJid, messageId, type, viewed)
            }
        }
    }

    fun updateViewedMessage(
        jid: String?,
        userJid: String?,
        messageId: String?,
        type: ReceiptType?,
        viewed: Boolean
    ): Boolean {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            updateViewedMessageAsync(jid, userJid, messageId, type, viewed)
            return false
        }
        try {
            if (messageId == null || type == null) return false
            val jids = buildJidList(jid, userJid)
            if (jids.isEmpty()) return false
            val primaryJid = jid ?: userJid!!

            val isViewedInt = if (viewed) 1 else 0
            val updatedRows = db.runInTransaction<Int> {
                if (userJid != null) {
                    hideSeenDao.updateUserJidIfNeeded(primaryJid, userJid, messageId)
                }
                if (type == ReceiptType.PLAYED) {
                    hideSeenDao.updatePlayed(jids, messageId, isViewedInt)
                } else {
                    hideSeenDao.updateRead(jids, messageId, isViewedInt)
                }
            }

            if (updatedRows <= 0) return false

            val cacheKey = createSeenMessageCacheKey(primaryJid, messageId, type)
            val cachedItem = seenMessageCache.get(cacheKey)

            if (cachedItem != null && (cachedItem === EMPTY_SEEN_ITEM || cachedItem.viewed != viewed)) {
                seenMessageCache.remove(cacheKey)
            }
            invalidateSeenMessagesListCache(primaryJid, type)

            hideSeenChangeListener?.onHideSeenChanged(primaryJid, messageId, type, viewed)
            return true
        } catch (t: Throwable) {
            YukiLog.log(t)
            return false
        }
    }

    fun updateViewedMessagesBatch(
        jid: String?,
        userJid: String?,
        messageIds: List<String>,
        type: ReceiptType?,
        viewed: Boolean
    ): Boolean {
        val jids = buildJidList(jid, userJid)
        if (jids.isEmpty() || type == null || messageIds.isEmpty()) return false
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Utils.databaseExecutor.execute {
                updateViewedMessagesBatch(jid, userJid, messageIds, type, viewed)
            }
            return false
        }
        try {
            val primaryJid = jid ?: userJid!!
            val isViewedInt = if (viewed) 1 else 0
            var updatedRows = 0
            db.runInTransaction {
                for (chunk in messageIds.chunked(BATCH_CHUNK_SIZE)) {
                    updatedRows += if (type == ReceiptType.PLAYED) {
                        hideSeenDao.updatePlayedBatch(jids, chunk, isViewedInt)
                    } else {
                        hideSeenDao.updateReadBatch(jids, chunk, isViewedInt)
                    }
                }
            }
            if (updatedRows <= 0) return false

            for (messageId in messageIds) {
                seenMessageCache.remove(createSeenMessageCacheKey(primaryJid, messageId, type))
                hideSeenChangeListener?.onHideSeenChanged(primaryJid, messageId, type, viewed)
            }
            invalidateSeenMessagesListCache(primaryJid, type)
            return true
        } catch (t: Throwable) {
            YukiLog.log(t)
            return false
        }
    }

    fun updateViewedMessageAsync(
        jid: String?,
        userJid: String?,
        messageId: String?,
        type: ReceiptType?,
        viewed: Boolean
    ) {
        Utils.databaseExecutor.execute {
            updateViewedMessage(jid, userJid, messageId, type, viewed)
        }
    }

    fun getHideSeenMessage(
        jid: String?,
        userJid: String?,
        messageId: String?,
        type: ReceiptType?
    ): MessageSeenItem? {
        try {
            if (messageId == null || type == null) return null
            val jids = buildJidList(jid, userJid)
            if (jids.isEmpty()) return null
            val primaryJid = jid ?: userJid!!

            val cacheKey = createSeenMessageCacheKey(primaryJid, messageId, type)
            val cachedItem = seenMessageCache.get(cacheKey)
            if (cachedItem != null) {
                return if (cachedItem === EMPTY_SEEN_ITEM) null else cachedItem
            }

            if (Looper.myLooper() == Looper.getMainLooper()) {
                scheduleCacheLoad(cacheKey) { getHideSeenMessage(jid, userJid, messageId, type) }
                return null
            }

            val state = if (type == ReceiptType.PLAYED) {
                hideSeenDao.getPlayedState(jids, messageId)
            } else {
                hideSeenDao.getReadState(jids, messageId)
            }

            if (state != null) {
                val viewed = state == 1
                val message = MessageSeenItem(jid, userJid, messageId, viewed)
                seenMessageCache.put(cacheKey, message)
                return message
            } else {
                seenMessageCache.put(cacheKey, EMPTY_SEEN_ITEM)
            }
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
        return null
    }

    fun getHideSeenMessages(
        jid: String?,
        userJid: String?,
        type: ReceiptType?,
        viewed: Boolean
    ): List<MessageSeenItem>? {
        try {
            if (type == null) return null
            val jids = buildJidList(jid, userJid)
            if (jids.isEmpty()) return null
            val primaryJid = jid ?: userJid!!

            val cacheKey = createSeenMessagesListCacheKey(primaryJid, type, viewed)
            val cachedList = seenMessagesListCache.get(cacheKey)
            if (cachedList != null) {
                return cachedList
            }

            if (Looper.myLooper() == Looper.getMainLooper()) {
                scheduleCacheLoad(cacheKey) { getHideSeenMessages(jid, userJid, type, viewed) }
                return null
            }

            val isViewedInt = if (viewed) 1 else 0
            val entities = if (type == ReceiptType.PLAYED) {
                hideSeenDao.getMessagesByPlayedState(jids, isViewedInt)
            } else {
                hideSeenDao.getMessagesByReadState(jids, isViewedInt)
            }

            if (entities.isNotEmpty()) {
                val messages = ArrayList<MessageSeenItem>()
                for (entity in entities) {
                    val message = MessageSeenItem(jid, userJid, entity.messageId, viewed)
                    messages.add(message)

                    // Alimenta também o cache individual
                    val msgCacheKey = createSeenMessageCacheKey(primaryJid, entity.messageId, type)
                    seenMessageCache.put(msgCacheKey, message)
                }
                seenMessagesListCache.put(cacheKey, messages)
                return messages
            } else {
                seenMessagesListCache.put(cacheKey, emptyList())
            }
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
        return null
    }

    fun insertDeviceInfo(userjid: String, messageId: String, deviceType: Int) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            insertDeviceInfoAsync(userjid, messageId, deviceType)
            return
        }

        try {
            deviceDao.insertOrReplace(
                DeviceEntity(
                    userjid = userjid,
                    messageId = messageId,
                    deviceType = deviceType
                )
            )
            val cacheKey = createDeviceCacheKey(userjid, messageId)
            synchronized(cacheLock) {
                deviceCache.put(cacheKey, deviceType)
                deviceCache.put(messageId, deviceType)
            }
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
    }

    fun insertDeviceInfoAsync(userjid: String, messageId: String, deviceType: Int) {
        Utils.databaseExecutor.execute {
            insertDeviceInfo(userjid, messageId, deviceType)
        }
    }

    fun getDeviceType(
        userjid: String?,
        messageId: String,
        onLoaded: (() -> Unit)? = null
    ): Int? {
        val cacheKey = if (userjid != null) createDeviceCacheKey(userjid, messageId) else messageId
        val cached = synchronized(cacheLock) {
            deviceCache.get(cacheKey) ?: deviceCache.get(messageId)
        }

        if (cached != null) {
            return if (cached == EMPTY_DEVICE_TYPE) null else cached
        }

        if (Looper.myLooper() == Looper.getMainLooper()) {
            scheduleCacheLoad("device:$cacheKey") {
                getDeviceType(userjid, messageId)
                onLoaded?.let { callback ->
                    mainHandler.post { callback() }
                }
            }
            return null
        }

        try {
            val type = if (userjid != null) {
                deviceDao.getDeviceType(userjid, messageId)
                    ?: deviceDao.getDeviceTypeByMessageId(messageId)
            } else {
                deviceDao.getDeviceTypeByMessageId(messageId)
            }

            synchronized(cacheLock) {
                if (type != null) {
                    deviceCache.put(cacheKey, type)
                    deviceCache.put(messageId, type)
                } else {
                    deviceCache.put(cacheKey, EMPTY_DEVICE_TYPE)
                    deviceCache.put(messageId, EMPTY_DEVICE_TYPE)
                }
            }
            return type
        } catch (t: Throwable) {
            YukiLog.log(t)
        }
        return null
    }

    fun clearCaches() {
        messagesCache.evictAll()
        seenMessageCache.evictAll()
        seenMessagesListCache.evictAll()
        synchronized(cacheLock) {
            deviceCache.evictAll()
        }
    }

    private fun scheduleCacheLoad(key: String, load: () -> Unit) {
        if (!loadingCacheKeys.add(key)) return
        Utils.databaseExecutor.execute {
            try {
                load()
            } finally {
                loadingCacheKeys.remove(key)
            }
        }
    }

    private fun buildJidList(jid: String?, userJid: String?): List<String> {
        return listOfNotNull(jid, userJid).distinct()
    }

    private fun createSeenMessageCacheKey(
        jid: String,
        messageId: String,
        type: ReceiptType
    ): String {
        return "${jid}_${messageId}_${type.ordinal}"
    }

    private fun createSeenMessagesListCacheKey(
        jid: String,
        type: ReceiptType,
        viewed: Boolean
    ): String {
        return "${jid}_${type.ordinal}_${if (viewed) "1" else "0"}"
    }

    private fun createDeviceCacheKey(userjid: String, messageId: String): String {
        return "${userjid}_${messageId}"
    }

    private fun invalidateSeenMessagesListCache(jid: String, type: ReceiptType) {
        seenMessagesListCache.remove(createSeenMessagesListCacheKey(jid, type, true))
        seenMessagesListCache.remove(createSeenMessagesListCacheKey(jid, type, false))
    }
}
